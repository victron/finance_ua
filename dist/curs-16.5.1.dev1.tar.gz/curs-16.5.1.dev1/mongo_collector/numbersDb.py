# numbers_good = {'380505682662' : [u'нивки', 'new', 'man', 1], \
#                 '380955351553' : [u'нивки', 'new', 'woman', 1]}
numbers_grey = {'380630127256' : [u'шулявка', 'old 300', 'man'], \
                '380955946570' : [u'шулявка', 'old 500', 'man'], \
                '380958617271' : [u'шулявка', '', '', 0, 'to check, everning']}

numbers_good = [{'number' : '380505682662',
                 'location': 'нивки',
                 'new': True,
                 'sex': 'man',
                 'met': 'I',
                 'conected_with' : ['380505682662']
                 },
                {'number' : '380505682662',
                 'location': 'нивки',
                 'new': True,
                 'sex': 'woman',
                 'met': False,
                 'conected_with': ['380955351553'],
                },
                {'number' : '380683500500',
                 'location': 'дарниця',
                 'new': True,
                 'sex': 'man',
                 'met': 'In',
                 },
                {'number' : '380664771640',
                 'location': 'квадрат',
                 'new': True,
                 'sex': 'man',
                 'met': 'In',
                 'professional': True},
                {'number' : ['380507814788', '380967660366', '380964818109'],
                 'location': 'левобережка',
                 'new': True,
                 'sex': 'woman',
                 'met': 'In',
                 'name': 'Катя'}]