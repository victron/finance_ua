# for deploy and then start it
from app import app

def main():
    app.run(debug = True)

if __name__ == '__main__':
    main()
