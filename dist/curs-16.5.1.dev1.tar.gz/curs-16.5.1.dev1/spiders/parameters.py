proxy = '135.245.192.7:8000'
proxies = {'http': proxy }

user_agent = '"Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)"'
headers = {'user-agent': user_agent}

# waite time before collect info
sleep_time = 300
proxy_is_used = False
news_type = 'currency'
# table settings
table_column_size = (5, 3, 4, 5, 7, 5, 30, 15, 1)