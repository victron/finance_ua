file_with_code = 'secret_data.pye'
stdinput = False
password = 'fin_sec!Kate'

