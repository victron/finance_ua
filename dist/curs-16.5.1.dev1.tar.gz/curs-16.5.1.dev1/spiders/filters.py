# -*- coding: utf-8 -*-
################  filter settings  ################
filter_or = u'новые юность черниговская дарница троещина воскресенка перова авто от'

# currently not works
filter_and = u''

currency = 'USD'
operation = 'sell'
location = 'Киев'

